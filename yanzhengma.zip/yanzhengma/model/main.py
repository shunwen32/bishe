import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

import albumentations as A
from albumentations.pytorch import ToTensorV2

import cv2
import numpy as np
from scipy.signal import find_peaks

from pathlib import Path
from tqdm import tqdm

from sklearn.metrics import accuracy_score, f1_score
import matplotlib.pyplot as plt

train_path = Path("train")
test_path = Path("test")

train_imgs = list(train_path.rglob("*.*"))
test_imgs = list(test_path.rglob("*.*"))

def find_char_boundaries(projection, num_chars=4):
    smoothed = np.convolve(projection, np.ones(5)/5, mode='same')
    
    valleys, _ = find_peaks(-smoothed, distance=5)
    
    valley_depths = [(v, smoothed[v]) for v in valleys]
    valley_depths.sort(key=lambda x: x[1]) 
    
    best_valleys = [v[0] for v in valley_depths[:num_chars-1]]
    best_valleys.sort()
    
    return best_valleys

label_map = {
    "0": 0,
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "A": 10,
    "B": 11,
    "C": 12,
    "D": 13,
    "E": 14,
    "F": 15,
    "G": 16,
    "H": 17,
    "I": 18,    
    "J": 19,
    "K": 20,
    "L": 21,
    "M": 22,
    "N": 23,
    "O": 24,
    "P": 25,
    "Q": 26,
    "R": 27,
    "S": 28,
    "T": 29,
    "U": 30,
    "V": 31,
    "W": 32,
    "X": 33,
    "Y": 34,
    "Z": 35,
    "a": 36,
    "b": 37,
    "c": 38,
    "d": 39,
    "e": 40,
    "f": 41,
    "g": 42,
    "h": 43,
    "i": 44,
    "j": 45,
    "k": 46,
    "l": 47,
    "m": 48,
    "n": 49,
    "o": 50,
    "p": 51,
    "q": 52,
    "r": 53,
    "s": 54,
    "t": 55,
    "u": 56,
    "v": 57,
    "w": 58,
    "x": 59,
    "y": 60,
    "z": 61
}

augmentations = A.Compose([
    A.HorizontalFlip(p=0.5),  # 水平翻转
    A.VerticalFlip(p=0.5),  # 垂直翻转
    A.RandomRotate90(p=0.5),  # 随机旋转90度
    A.RandomBrightnessContrast(p=0.2),  # 随机亮度对比度调整
    A.GaussNoise(p=0.2),  # 添加高斯噪声
    A.ShiftScaleRotate(shift_limit=0.1, scale_limit=0.1, rotate_limit=15, p=0.5)  # 平移、缩放和旋转 
])

# 基本转换
transforms = A.Compose([
    A.Resize(height=32, width=32), 
    A.Normalize(mean=0.5, std=0.5),
    ToTensorV2()
])

class CustomDataset(Dataset):
    def __init__(self, img_paths, transform=None, augmentations=None):
        self.img_paths = img_paths
        self.transform = transform
        self.augmentations = augmentations
        self.imgs = []
        self.labels = []
        for img_path in tqdm(img_paths, desc="Loading images"):
            img = cv2.imread(str(img_path))
            name = img_path.stem[:4]
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, img_binary = cv2.threshold(img_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            img_binary = cv2.bitwise_not(img_binary)
            verical_projection = img_binary.sum(axis=0)
            split_points = find_char_boundaries(verical_projection)
            split_points = [0] + split_points + [img_binary.shape[1]]
            
            if len(split_points) < 5:
                continue
            for i in range(len(split_points) - 1):
                char_img = img_binary[:, split_points[i]:split_points[i+1]]
                self.imgs.append(char_img)
                self.labels.append(label_map[name[i]])
                
    def __len__(self):
        return len(self.imgs)
    def __getitem__(self, idx):
        img = self.imgs[idx]
        label = self.labels[idx]
        
        if self.augmentations:
            augmented = self.augmentations(image=img)
            img = augmented['image']
        
        if self.transform:
            img = self.transform(image=img)['image']
        
        return img, label
    
# hyperparameters
batch_size = 256
learning_rate = 0.001
num_epochs = 50
num_classes = len(label_map)
device = torch.device("cuda:4" if torch.cuda.is_available() else "cpu")

# dataset and dataloader
train_dataset = CustomDataset(train_imgs, transform=transforms, augmentations=augmentations)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_dataset = CustomDataset(test_imgs, transform=transforms)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# model LeNet
def conv_block(in_channels, out_channels):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(),
        nn.MaxPool2d(kernel_size=2, stride=2)
    )

class LeNet(nn.Module):
    def __init__(self, num_classes=62):
        super(LeNet, self).__init__()
        
        self.features = nn.Sequential(
            conv_block(1, 16),    # 输入: 1x32x32, 输出: 16x16x16
            conv_block(16, 32),   # 输入: 16x16x16, 输出: 32x8x8
            conv_block(32, 64),   # 输入: 32x8x8, 输出: 64x4x4
        )
        
        # 分类部分
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 4 * 4, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x
            
# model
model = LeNet(num_classes=num_classes).to(device)
# loss and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

losses = []
acces = []
f1_scores = []

# training
for epoch in range(num_epochs):
    model.train()
    for i, (images, labels) in tqdm(enumerate(train_loader), desc=f"Epoch {epoch+1}/{num_epochs}"):
        images = images.to(device)
        labels = labels.to(device)
        
        # forward pass
        outputs = model(images)
        loss = criterion(outputs, labels)
        
        # backward pass and optimization
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(f'Epoch [{epoch+1}/{num_epochs}], Step [{i+1}/{len(train_loader)}], Loss: {loss.item():.4f}')
    
    losses.append(loss.item())
    # test
    model.eval()
    with torch.no_grad():
        mean_acc = 0
        mean_f1 = 0
        for images, labels in tqdm(test_loader, desc="Testing"):
            images = images.to(device)
            labels = labels.to(device)
            
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            
            # calculate accuracy
            acc = accuracy_score(labels.cpu(), predicted.cpu())
            f1 = f1_score(labels.cpu(), predicted.cpu(), average='weighted')
            
            mean_acc += acc
            mean_f1 += f1
            
            acces.append(acc)
            f1_scores.append(f1)
        print(f'Accuracy: {mean_acc/len(test_loader):.4f}, F1 Score: {mean_f1/len(test_loader):.4f}')
    # save model
    torch.save(model.state_dict(), f'model.pth')
    
# plot loss
plt.plot(losses)
plt.title('Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.savefig('loss.png')

# clear the figure
plt.clf()

# plot accuracy
plt.plot(acces)
plt.title('Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.savefig('accuracy.png')

# clear the figure
plt.clf()
# plot f1 score
plt.plot(f1_scores)
plt.title('F1 Score')
plt.xlabel('Epoch')
plt.ylabel('F1 Score')
plt.savefig('f1_score.png')