import torch
import torch.nn as nn
import torch.nn.functional as F

import cv2
import numpy as np
from scipy.signal import find_peaks

def find_char_boundaries(projection, num_chars=4):
    smoothed = np.convolve(projection, np.ones(5)/5, mode='same')
    
    valleys, _ = find_peaks(-smoothed, distance=5)
    
    valley_depths = [(v, smoothed[v]) for v in valleys]
    valley_depths.sort(key=lambda x: x[1]) 
    
    best_valleys = [v[0] for v in valley_depths[:num_chars-1]]
    best_valleys.sort()
    
    return best_valleys

def conv_block(in_channels, out_channels):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(),
        nn.MaxPool2d(kernel_size=2, stride=2)
    )

class LeNet(nn.Module):
    def __init__(self, num_classes=62):
        super(LeNet, self).__init__()
        
        self.features = nn.Sequential(
            conv_block(1, 16),    # 输入: 1x32x32, 输出: 16x16x16
            conv_block(16, 32),   # 输入: 16x16x16, 输出: 32x8x8
            conv_block(32, 64),   # 输入: 32x8x8, 输出: 64x4x4
        )
        
        # 分类部分
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 4 * 4, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x
label_map = {
    "0": 0,
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "A": 10,
    "B": 11,
    "C": 12,
    "D": 13,
    "E": 14,
    "F": 15,
    "G": 16,
    "H": 17,
    "I": 18,    
    "J": 19,
    "K": 20,
    "L": 21,
    "M": 22,
    "N": 23,
    "O": 24,
    "P": 25,
    "Q": 26,
    "R": 27,
    "S": 28,
    "T": 29,
    "U": 30,
    "V": 31,
    "W": 32,
    "X": 33,
    "Y": 34,
    "Z": 35,
    "a": 36,
    "b": 37,
    "c": 38,
    "d": 39,
    "e": 40,
    "f": 41,
    "g": 42,
    "h": 43,
    "i": 44,
    "j": 45,
    "k": 46,
    "l": 47,
    "m": 48,
    "n": 49,
    "o": 50,
    "p": 51,
    "q": 52,
    "r": 53,
    "s": 54,
    "t": 55,
    "u": 56,
    "v": 57,
    "w": 58,
    "x": 59,
    "y": 60,
    "z": 61
}

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = LeNet(num_classes=62).to(device)
model.load_state_dict(torch.load("model.pth", map_location=device))

model.eval()

