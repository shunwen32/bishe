import sys
import os
import numpy as np
import cv2
from PyQt5.QtWidgets import (QApplication, QMainWindow, QLabel, QPushButton, 
                             QVBoxLayout, QHBoxLayout, QFileDialog, QWidget)
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt

# 导入您的推理模块
import torch
from infer import model, device, find_char_boundaries, label_map
import albumentations as A
from albumentations.pytorch import ToTensorV2

# 反向映射标签
inverse_label_map = {v: k for k, v in label_map.items()}
transforms = A.Compose([
    A.Resize(height=32, width=32), 
    A.Normalize(mean=0.5, std=0.5),
    ToTensorV2()
])

class VerificationCodeApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("验证码识别")
        self.setGeometry(100, 100, 600, 400)
        
        # 创建主部件和布局
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        main_layout = QVBoxLayout(self.central_widget)
        
        # 图像显示区域
        self.image_label = QLabel("请选择一张图片")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(300, 150)
        self.image_label.setStyleSheet("border: 1px solid #ccc;")
        main_layout.addWidget(self.image_label)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        
        self.select_button = QPushButton("选择图片")
        self.select_button.clicked.connect(self.select_image)
        button_layout.addWidget(self.select_button)
        
        self.process_button = QPushButton("开始识别")
        self.process_button.clicked.connect(self.process_image)
        self.process_button.setEnabled(False)  # 初始禁用
        button_layout.addWidget(self.process_button)
        
        main_layout.addLayout(button_layout)
        
        # 结果显示区域
        self.result_label = QLabel("识别结果将显示在这里")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setStyleSheet("font-size: 18px; margin-top: 20px;")
        main_layout.addWidget(self.result_label)
        
        # 保存图像路径
        self.image_path = None
        
    def select_image(self):
        file_dialog = QFileDialog()
        image_path, _ = file_dialog.getOpenFileName(
            self, "选择图片", "", "图像文件 (*.png *.jpg *.jpeg *.bmp)"
        )
        
        if image_path:
            self.image_path = image_path
            pixmap = QPixmap(image_path)
            
            # 调整大小保持比例
            scaled_pixmap = pixmap.scaled(
                300, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            
            self.image_label.setPixmap(scaled_pixmap)
            self.process_button.setEnabled(True)
            self.result_label.setText("点击'开始识别'按钮识别验证码")
    
    def process_image(self):
        if not self.image_path:
            return
        
        try:
            img = cv2.imread(self.image_path)
            if img is None:
                self.result_label.setText("图像读取失败")
                return
            
            # 预处理图像
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, img_binary = cv2.threshold(img_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            img_binary = cv2.bitwise_not(img_binary)
            verical_projection = img_binary.sum(axis=0)
            split_points = find_char_boundaries(verical_projection)
            split_points = [0] + split_points + [img_binary.shape[1]]
            
            # 初始化结果字符串
            result = ""
            
            for i in range(len(split_points) - 1):
                left = split_points[i]
                right = split_points[i + 1]
                char_img = img_binary[:, left:right]
                char_tensor = transforms(image=char_img)["image"]
                char_tensor = char_tensor.unsqueeze(0).to(device)
                # 预测
                with torch.no_grad():
                    output = model(char_tensor)
                    _, predicted = torch.max(output, 1)
                    label_idx = predicted.item()
                    char = inverse_label_map.get(label_idx, "?")
                    result += char
            
            self.result_label.setText(f"识别结果: {result}")
            
        except Exception as e:
            self.result_label.setText(f"处理过程中出错: {str(e)}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VerificationCodeApp()
    window.show()
    sys.exit(app.exec_())